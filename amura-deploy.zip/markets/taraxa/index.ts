import { IAaveConfiguration, eTaraxaNetwork } from "../../helpers/types";
import { AaveMarket } from "../aave/index";
import {
  strategyWTARA,
  strategyUSDC,
  strategyUSDT,
  strategyUSDM,
  strategyETH,
  strategyLINK,
  strategyAMR,
} from "./reservesConfigs";

export const TaraxaMarket: IAaveConfiguration = {
  ...AaveMarket,
  ProviderId: 40,
  WrappedNativeTokenSymbol: "WTARA",
  MarketId: "Amura Taraxa Market",
  ATokenNamePrefix: "Taraxa",
  StableDebtTokenNamePrefix: "Taraxa",
  VariableDebtTokenNamePrefix: "Taraxa",
  SymbolPrefix: "Tara",
  ReservesConfig: {
    WTARA: strategyWTARA,
    USDT: strategyUSDT,
    USDC: strategyUSDC,
    USDM: strategyUSDM,
    ETH: strategyETH,
    LINK: strategyLINK,
    AMR: strategyAMR
  },
  ReserveAssets: {
    [eTaraxaNetwork.main]: {
      WTARA: "0x0000000000000000000000000000000000000000",
      USDC: "0x0000000000000000000000000000000000000000",
      USDT: "0x0000000000000000000000000000000000000000",
      USDM: "0x0000000000000000000000000000000000000000",
      ETH: "0x0000000000000000000000000000000000000000",
      LINK: "0x0000000000000000000000000000000000000000",
      AMR: "0x0000000000000000000000000000000000000000",
    },
    [eTaraxaNetwork.testnet]: {
      WTARA: "0x5EdD57af6B3269FDc9bB81B407d86Bbd269518BA",
      USDC: "0x5E8EB331235b2F4b56d6afF404e856EeD788b77a",
      USDT: "0x51571964eE624E8D6cADA833981990965CeA277B",
      USDM: "0x04558C406067E2E35cd2a96c0750ceE0c399Bd11",
      ETH: "0x646156A249B7BD0545998f4472ce2DAf8f5924bd",
      LINK: "0xF62EE6C5404DBFB0D0F9eEceB6BAb3C64891A0AA",
      AMR: "0x3A70cAC8B5CeC8529A6a0efE0127F29186d1F42e",
    },
  },
  // ReserveFactorTreasuryAddress: {
  //   [eBitfinityNetwork.main]: "",
  // },
  EModes: {
    StableEMode: {
      id: "1",
      ltv: "9700",
      liquidationThreshold: "9750",
      liquidationBonus: "10100",
      label: "Stablecoins",
      assets: [],
    },
  },
  ChainlinkAggregator: {
    [eTaraxaNetwork.main]: {
      WTARA: "0x0000000000000000000000000000000000000000",
      USDC: "0x0000000000000000000000000000000000000000",
      USDT: "0x0000000000000000000000000000000000000000",
      USDM: "0x0000000000000000000000000000000000000000",
      ETH: "0x0000000000000000000000000000000000000000",
      LINK: "0x0000000000000000000000000000000000000000",
      AMR: "0x0000000000000000000000000000000000000000",
    },
    [eTaraxaNetwork.testnet]: {
      WTARA: "0x0E1732CBf90b46f31A074573ba0bc8a9E5250Cc1",
      USDC: "0xB3D6Ed5583D2D5A8Ef7736ebd9FFF96c511aF080",
      USDT: "0xB3D6Ed5583D2D5A8Ef7736ebd9FFF96c511aF080",
      USDM: "0xB3D6Ed5583D2D5A8Ef7736ebd9FFF96c511aF080",
      ETH: "0x9B97DC40A5CAb6b19e39FBFA8a1389E77dB19431",
      LINK: "0x64c078068d21d6E9046C55dc7165c09Fc8c59CeB",
      AMR: "0x17F1F367E8Bde9cc4077bbfd9B7fa49Af1FFeB57",
    },
  },
};

export default TaraxaMarket;
